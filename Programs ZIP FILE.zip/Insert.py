import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='pysupportdb')
curs=con.cursor()

try:
    no=int(input('Enter account number : '))
    nm=input('Enter name : ')
    ty=input('Enter type : ')
    bal=float(input('Enter balance : '))

    curs.execute("insert into accounts values(%d,'%s','%s',%.2f)" %(no,nm,ty,bal))
    con.commit()
    print('account opened successfully')
except:
    print('cant open account..invalid input, duplicate account number,balance<500')

con.close()
