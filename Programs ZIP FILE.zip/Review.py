import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

try:
    no=int(input('Enter Book Code : '))
    curs.execute("select * from books " )
    rw=input('enter review : ')
    curs.execute("update books set review where bookcode=%d" %(rw,no))
    con.commit()
    print('Record updated successfully')
except:
    print('Book code does not exist')

con.close()

