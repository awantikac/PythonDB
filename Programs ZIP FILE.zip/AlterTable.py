import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

try:
    curs.execute("alter table books add review varchar(500) " )
    con.commit()
    print('review column added successfully')
except:
    print('cant enter review')

con.close()
