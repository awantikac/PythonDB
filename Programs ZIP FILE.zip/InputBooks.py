import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

try:
    no=int(input('Enter Bookcode : '))
    nm=input('Enter Bookname : ')
    ct=input('Enter Category :')
    at=input('Enter Author : ')
    pb=input('Enter Publication  : ')
    pc=float(input('Enter price : '))

    curs.execute("insert into books values(%d,'%s','%s','%s','%s',%.2f)" %(no,nm,ct,at,pb,pc))
    con.commit()
    print('Book Values Inserted Successfully')
except:
    print('Invalid Input')
    con.close()

