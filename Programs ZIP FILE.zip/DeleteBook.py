import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

try:
    no=int(input('Enter bookcode to delete : '))
    curs.execute("select * from books  where bookcode=%d" %no)
    data=curs.fetchall()
    if data:
        curs.execute("delete from books where bookcode=%d" %no)
        con.commit()
        print('Account deleted successfully')
    else:
        print('Account does not exist')
except:
    print('error in deletion')

con.close()
