import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

no=int(input('Enter book code : '))
curs.execute("select bookcode,bookname from books where bookcode=%d" %no)
rec=curs.fetchone()
print(rec)

try:
    print('BookName    : %s' %rec[0])
    print('Bookcode : %d' %rec[1])
except:
    print('bookcode not found')

con.close()