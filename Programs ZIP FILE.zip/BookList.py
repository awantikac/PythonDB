import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

curs.execute("select * from books")
data=curs.fetchall()

print(data)
print('-'*30)

for rec in data:
    #print(rec)
    print(rec[1])

con.close()