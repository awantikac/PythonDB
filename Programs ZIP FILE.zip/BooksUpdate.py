import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()
try:
    no=int(input('Enter bookcode : '))
    curs.execute("select * from books where bookcode=%d" %no)
    data=curs.fetchall()
    pc=int(input('Enter Price : '))
    curs.execute("update books set price=%d where bookcode=%d" %(pc,no))
    con.commit()
    print(' updated successfully')
except:   
    print('Error in updation')
con.close()



       