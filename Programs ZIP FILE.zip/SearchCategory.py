import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

cg=input('Enter Category : ')
curs.execute("select bookname from books where category=%s" %cg )

rec=curs.fetchone()
#print(rec)

try:
    print('Book Name : %s' %rec[0])
except:
    print('category does not exist') 

con.close()

