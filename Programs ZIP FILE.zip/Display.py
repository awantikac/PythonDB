import pymysql as mycon

con=mycon.connect(host='localhost',user='root',password='TaylorSwift',database='bookstoredb')
curs=con.cursor()

try:
   
    nm=input('Enter  Author Name : ')
    pb=input('Enter publication : ')
    curs.execute("insert into new values('%s','%s')" %(nm,pb))
    con.commit()
    print('values inserted successfully')
except:
    print('cant insert values..invalid input')

con.close()
